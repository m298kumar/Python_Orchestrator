"""
Requirements Reader - Supports .txt, .pdf, .docx, .csv, .xlsx
"""
import os
import csv
import json
from pathlib import Path
from typing import List, Dict, Any
from dataclasses import dataclass, field
from rich.console import Console

console = Console()


@dataclass
class Requirement:
    """Represents a single requirement"""
    req_id: str
    title: str
    description: str
    priority: str = "Medium"
    category: str = "Functional"
    acceptance_criteria: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    raw_text: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "req_id": self.req_id,
            "title": self.title,
            "description": self.description,
            "priority": self.priority,
            "category": self.category,
            "acceptance_criteria": self.acceptance_criteria,
            "tags": self.tags,
        }

    def to_chroma_document(self) -> str:
        """Convert to document string for ChromaDB embedding"""
        parts = [
            f"Requirement ID: {self.req_id}",
            f"Title: {self.title}",
            f"Description: {self.description}",
            f"Priority: {self.priority}",
            f"Category: {self.category}",
        ]
        if self.acceptance_criteria:
            parts.append("Acceptance Criteria:")
            for ac in self.acceptance_criteria:
                parts.append(f"  - {ac}")
        return "\n".join(parts)


class RequirementsReader:
    """Reads and parses requirements from various file formats"""

    SUPPORTED_FORMATS = {".txt", ".pdf", ".docx", ".csv", ".xlsx", ".json", ".md"}

    def read(self, file_path: str) -> List[Requirement]:
        """Main entry point - detect format and parse"""
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"Requirements file not found: {file_path}")

        ext = path.suffix.lower()
        if ext not in self.SUPPORTED_FORMATS:
            raise ValueError(
                f"Unsupported format: {ext}. Supported: {self.SUPPORTED_FORMATS}"
            )

        console.print(f"[cyan]📄 Reading requirements from:[/cyan] {path.name}")

        readers = {
            ".txt": self._read_txt,
            ".md": self._read_txt,
            ".pdf": self._read_pdf,
            ".docx": self._read_docx,
            ".csv": self._read_csv,
            ".xlsx": self._read_xlsx,
            ".json": self._read_json,
        }

        requirements = readers[ext](str(path))
        console.print(
            f"[green]✅ Loaded {len(requirements)} requirement(s)[/green]"
        )
        return requirements

    def _read_txt(self, file_path: str) -> List[Requirement]:
        """Parse plain text / markdown requirements file"""
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        requirements = []
        # Try to parse structured format first (REQ-001: Title\nDescription...)
        blocks = self._split_into_blocks(content)

        if blocks:
            for i, block in enumerate(blocks):
                req = self._parse_text_block(block, i + 1)
                requirements.append(req)
        else:
            # Treat the whole file as a single requirement description
            req = Requirement(
                req_id="REQ-001",
                title="System Requirements",
                description=content.strip(),
                raw_text=content,
            )
            requirements.append(req)

        return requirements

    def _read_pdf(self, file_path: str) -> List[Requirement]:
        """Parse PDF requirements file"""
        try:
            import PyPDF2
        except ImportError:
            raise ImportError("PyPDF2 not installed. Run: pip install PyPDF2")

        text_parts = []
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text_parts.append(page.extract_text())

        full_text = "\n".join(text_parts)
        return self._read_txt_from_string(full_text)

    def _read_docx(self, file_path: str) -> List[Requirement]:
        """Parse Word document requirements"""
        try:
            from docx import Document
        except ImportError:
            raise ImportError("python-docx not installed. Run: pip install python-docx")

        doc = Document(file_path)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        full_text = "\n".join(paragraphs)
        return self._read_txt_from_string(full_text)

    def _read_csv(self, file_path: str) -> List[Requirement]:
        """Parse CSV requirements file.

        Expected columns (flexible matching):
        - id/req_id/requirement_id
        - title/name/summary
        - description/details/content
        - priority
        - category/type
        - acceptance_criteria/ac
        """
        requirements = []

        with open(file_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for i, row in enumerate(reader):
                row_lower = {k.lower().strip(): v for k, v in row.items()}

                req_id = (
                    row_lower.get("id")
                    or row_lower.get("req_id")
                    or row_lower.get("requirement_id")
                    or f"REQ-{i + 1:03d}"
                )
                title = (
                    row_lower.get("title")
                    or row_lower.get("name")
                    or row_lower.get("summary")
                    or f"Requirement {i + 1}"
                )
                description = (
                    row_lower.get("description")
                    or row_lower.get("details")
                    or row_lower.get("content")
                    or row_lower.get("requirement")
                    or ""
                )
                priority = row_lower.get("priority", "Medium")
                category = (
                    row_lower.get("category") or row_lower.get("type", "Functional")
                )
                ac_raw = (
                    row_lower.get("acceptance_criteria")
                    or row_lower.get("ac")
                    or ""
                )
                acceptance_criteria = (
                    [ac.strip() for ac in ac_raw.split(";") if ac.strip()]
                    if ac_raw
                    else []
                )

                requirements.append(
                    Requirement(
                        req_id=str(req_id).strip(),
                        title=str(title).strip(),
                        description=str(description).strip(),
                        priority=str(priority).strip(),
                        category=str(category).strip(),
                        acceptance_criteria=acceptance_criteria,
                    )
                )

        return requirements

    def _read_xlsx(self, file_path: str) -> List[Requirement]:
        """Parse Excel requirements file"""
        try:
            import pandas as pd
        except ImportError:
            raise ImportError("pandas not installed. Run: pip install pandas openpyxl")

        df = pd.read_excel(file_path)
        # Save to temp CSV and reuse CSV reader logic
        import tempfile

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".csv", delete=False, encoding="utf-8"
        ) as tmp:
            df.to_csv(tmp.name, index=False)
            return self._read_csv(tmp.name)

    def _read_json(self, file_path: str) -> List[Requirement]:
        """Parse JSON requirements file"""
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and "requirements" in data:
            items = data["requirements"]
        else:
            items = [data]

        requirements = []
        for i, item in enumerate(items):
            requirements.append(
                Requirement(
                    req_id=item.get("id", f"REQ-{i + 1:03d}"),
                    title=item.get("title", item.get("name", f"Requirement {i + 1}")),
                    description=item.get("description", item.get("details", "")),
                    priority=item.get("priority", "Medium"),
                    category=item.get("category", item.get("type", "Functional")),
                    acceptance_criteria=item.get("acceptance_criteria", []),
                    tags=item.get("tags", []),
                )
            )

        return requirements

    # ──────────────────────────── helpers ────────────────────────────

    def _read_txt_from_string(self, text: str) -> List[Requirement]:
        """Helper: parse text string as if reading a .txt file"""
        import tempfile

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, encoding="utf-8"
        ) as tmp:
            tmp.write(text)
            return self._read_txt(tmp.name)

    def _split_into_blocks(self, content: str) -> List[str]:
        """Split content into requirement blocks"""
        import re

        # Try common separators
        patterns = [
            r"\n(?=REQ-\d+)",          # REQ-001 style
            r"\n(?=\d+\.\s)",           # 1. numbered style
            r"\n(?=#{1,3}\s)",          # ## heading style
            r"\n---+\n",                # --- divider style
            r"\n===+\n",                # === divider style
        ]

        for pattern in patterns:
            blocks = re.split(pattern, content.strip())
            if len(blocks) > 1:
                return [b.strip() for b in blocks if b.strip()]

        return []

    def _parse_text_block(self, block: str, index: int) -> Requirement:
        """Parse a single text block into a Requirement"""
        import re

        lines = block.strip().split("\n")
        first_line = lines[0].strip()

        # Extract ID if present
        id_match = re.match(r"^(REQ-\d+|#\d+|\d+\.)\s*(.*)", first_line)
        if id_match:
            req_id = id_match.group(1).rstrip(".")
            title = id_match.group(2).strip().lstrip("#").strip()
        else:
            req_id = f"REQ-{index:03d}"
            title = first_line.lstrip("#").strip()

        description = "\n".join(lines[1:]).strip()

        # Extract acceptance criteria
        ac = []
        ac_match = re.findall(
            r"(?:acceptance criteria|ac|given|when|then)[:\s]+(.+)", 
            description, 
            re.IGNORECASE
        )
        for match in ac_match:
            ac.append(match.strip())

        return Requirement(
            req_id=req_id,
            title=title,
            description=description,
            acceptance_criteria=ac,
            raw_text=block,
        )
